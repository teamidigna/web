"use strict";

function Idigna_Contact_Form() {
    
    if ( jQuery('input[name]:not(.is-init), textarea[name]:not(.is-init)').length ) {
        jQuery('input[name]:not(.is-init), textarea[name]:not(.is-init)').each(function() {
            let $this = jQuery(this);
            $this.addClass('is-init');
            $this.on('focus', function() {
                jQuery('label[for="'+ $this.attr('name') +'"]').addClass('in-focus');
            }).on('blur', function() {
                jQuery('label[for="'+ $this.attr('name') +'"]').removeClass('in-focus');
            });
        });
    }

    
    if ( jQuery('.Idigna-contact-form:not(.is-init)').length ) {
        jQuery('.Idigna-contact-form:not(.is-init)').each(function() {
            let $form = jQuery(this),
                $response = $form.find('.Idigna-contact-form__response'),
                formData;

            $response.slideUp(1);
            
            $form.addClass('is-init');
            
            $form.on('submit', function(e) {
                e.preventDefault();
                
                $form.addClass('is-busy');
                $response.slideUp(200);

                
                formData = $form.serialize();
                jQuery.ajax({
                    type: 'POST',
                    url: $form.attr('action'),
                    data: formData
                })
                .done(function(response) {
                    $form.removeClass('is-busy');
                    $response.empty().removeClass('Idigna-alert-danger').addClass('Idigna-alert-success').slideDown(200);
                    $response.html('<span>' + response + '</span>');
                    $form.find('input:not([type="submit"]), textarea').val('');
                    setTimeout(function() {
                        $response.slideUp(200, function() {
                            jQuery(this).empty();
                        });
                    }, 5000, $response);
                })
                .fail(function(data) {
                    $form.removeClass('is-busy');
                    $response.empty().removeClass('Idigna-alert-success').addClass('Idigna-alert-danger').slideDown(200);
                    $response.html('<span>' + data.responseText + '</span>');
                    $form.addClass('is-error');
                    setTimeout(function() {
                        $form.removeClass('is-error');
                    }, 500, $form);
                });

            });
        });
    }
}